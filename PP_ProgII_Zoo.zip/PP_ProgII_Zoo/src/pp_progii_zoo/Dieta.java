package pp_progii_zoo;

public enum Dieta {
    CARNIVORO,
    HERBIVORO,
    OMNIVORO
}
