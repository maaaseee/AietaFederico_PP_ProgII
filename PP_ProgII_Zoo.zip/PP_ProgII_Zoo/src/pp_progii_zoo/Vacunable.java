
package pp_progii_zoo;

public interface Vacunable {
    
    public abstract void vacunar();
}
